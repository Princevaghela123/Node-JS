require('./config/db.config');
const express = require('express');
const watch = require("./model/watch.model");
const multer = require('multer');
const path = require('path')
const fs = require('fs');

const PORT = 9000;
const app = express();

app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded());
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Table Route
app.get('/', async (req, res) => {

    // All Book Fetch
    const allwatch = await watch.find();

    // console.log(allBooks);

    return res.render('watch_details', { allwatch });
});

// Add Book Roate (watch_form.ejs)
app.get('/addwatchpage', (req, res) => {
    return res.render('watch_form');
});

// Multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    }
});

// Image Middleware
const upload = multer({ storage });

// Insert watch Logic
app.post('/addwatch', upload.single('watch_image'), async (req, res) => {

    console.log(req.body);

    // const watchData = req.body

    console.log(req.file);

    req.body.watch_image = req.file.path;

    const watchAdded = await watch.create(req.body);

    console.log(watchAdded);

    if (watchAdded) {
        console.log("Book inserted Successfully...");
    } else {
        console.log("Book insertion failed...");
    }
    return res.redirect('/');

});

// Edit Route
app.get('/editwatch/:watchId', async (req, res) => {
    console.log(req.params); 

    const mywatch = await watch.findById(req.params.watchId);

    console.log(mywatch);

    if (mywatch) {
        return res.render('watch_edit', { mywatch });
    } else {
        return res.redirect('/');
    }
});



// Update watch Logic
app.post('/updatewatch', upload.single('watch_image'), async (req, res) => {
    console.log(req.body);

    console.log(req.file);

    if (req.file) {
        // Old Image remove
        const watchData = await watch.findById(req.body.id);

        fs.unlink(watchData.watch_image, (err) => { });

        // New Image store (Path)
        req.body.watch_image = req.file.path;

        const updatedData = await watch.findByIdAndUpdate(req.body.id, req.body, { new: true });

        console.log("Update : ", updatedData);

    } else {
        const updatedData = await watch.findByIdAndUpdate(req.body.id, req.body, { new: true });

        console.log("Update : ", updatedData);
    }

    return res.redirect('/');
});

// Delete watch Logic
app.get('/deletewatch', async (req, res) => {
    console.log(req.query);

    const deletedwatch = await watch.findByIdAndDelete(req.query.watchId);

    console.log("Deleted watch : ", deletedwatch);

     fs.unlink(deletedwatch.watch_image, (err) => { });

    if (deletedwatch) {
        console.log("watch deleted successfully...");
    } else {
        console.log("watch deletion failed...");
    }
    return res.redirect('/');
});

/**
 * MVC Pattern: 
 *  
 *  M - Model => Schema == Structure / Design
 *  V - Views
 *  C - Controllers
 * 
 * 
 *  CRUD -
 *      C - Create / Insert
 *      R - Read / Fetch / Retrive
 *      U - Update
 *      D - Delete
 * 
 *  Mongoose (Model) :
 *  Insert : create(body)
 *          body :- object {name: "ABC", age: 12}
 *          return : Added Single Data  
 *          not insertion : return null
 * 
 *  Fetch : find() 
 *          return : Array of Objects [{}, {}]
 *          not inserted : return Empty Array []
 * 
 *  Delete : findByIdAndDelete(id)
 *          return : Delete Single Data
 *          not deletion : return null
 * 
 *  Update : findByIdAndUpdate(id, body , {new : true});
 *          return : new Updated Data
 *          not updation : return null 
 * 
 *  Single Data Fetch Using Id : findById(id)
 *          return : Single Data (Match ID)
 *          not match : return null
 */

app.listen(PORT, (err) => {
    if (err) {
        console.log("Server is not started..", err);
        return;
    }
    console.log("Server is strated 😂");
});